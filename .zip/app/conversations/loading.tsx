import LoadingModal from "../components/LoadingModal";

const Loading = () => {
    return <LoadingModal />;
};

export default Loading;
